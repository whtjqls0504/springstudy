package com.gdu.movie.service;

import java.util.Map;

public interface MovieService {

  // public List<MovieDto> getMovieList();  하고연결
  public Map<String, Object> getMovieList();
  
  
}
